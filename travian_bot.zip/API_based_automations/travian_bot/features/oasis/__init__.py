"""
Oasis raiding functionality.
""" 